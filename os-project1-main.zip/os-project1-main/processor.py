# pylint: skip-file

from typing import Optional
from generate import Process


class Processor:
    def __init__(
        self,
        speed: int = 1,
        memory: int = 1,
        limit: Optional[int] = None,
    ) -> None:
        self.speed = speed
        self.memory = memory
        self.process = None
        self.consecutive_cycles = 0
        self.limit = limit

    def set_process(self, process: Process) -> None:
        self.process = process
        self.consecutive_cycles = 0

    def do_cycle(self) -> bool:
        if not self.process or self.process.cycles == 0:
            return False
        if self.limit and self.consecutive_cycles == self.limit:
            # used for round robin to limit cycles per cpu
            return False
        self.process.cycles -= 1
        self.consecutive_cycles += 1
        return True

    def __repr__(self) -> str:
        return f"Processor<{self.consecutive_cycles}, process={self.process}>"
