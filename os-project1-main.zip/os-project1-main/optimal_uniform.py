from dataclasses import dataclass, field
from pprint import pprint
from heapq import heapify, heappop, heappush
from statistics import mean
import itertools
from random import randint

# pylint: skip-file


@dataclass(order=True)
class Processor:
    speed: int = field(compare=False)
    i: int = 0
    r: set = field(default_factory=set, compare=False)

    def add(self, num):
        self.r.add(num)
        self.i += 1 / self.speed

    def get_total_time(self):
        return sum(self.r) / self.speed

    def get_turnaround_time(self):
        if not self.r:
            return 0
        arr = list(sorted(self.r))

        return mean(itertools.accumulate(arr)) / self.speed

    def average_waiting(self):
        arr = list(sorted(self.r))
        res = []
        for idx, val in enumerate(itertools.accumulate(arr)):
            res.append(val - arr[idx])
        return mean(res) / self.speed


def optimal(s, t):
    m = len(s)  # number of processors
    n = len(t) - 1
    t.sort()
    for j in range(m - 1):
        s[j].i = 1 / s[j].speed
    fastest_process = s[m - 1]
    fastest_process.i = 2 / fastest_process.speed
    fastest_process.r = set([t[n]])
    # heapify(s)
    for k in reversed(range(n - 1)):
        smallest_i_process = min(s, key=lambda x: x.i)
        smallest_i_process.add(t[k])

    avg_times = [p.get_total_time() for p in s]
    # for p in s:
    #     print(p)
    pprint(sorted(s))
    pprint(avg_times)
    pprint(sum(avg_times) / len(avg_times))
    turn_arounds = [p.get_turnaround_time() for p in s]
    pprint(turn_arounds)
    pprint(f"average turn around = {mean(turn_arounds)}")
    avg_waiting = [p.average_waiting() for p in s]
    pprint(avg_waiting)
    pprint(f"average waiting around = {mean(avg_waiting)}")


if __name__ == "__main__":
    s = [Processor(2), Processor(3), Processor(5)]  # processor speeds
    # t = [10, 100, 390, 440, 510, 519]  # times of processes
    t = [randint(100, 2000) for _ in range(100)]  # times of processes
    optimal(s, t)
