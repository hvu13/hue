# pylint: skip-file
"""
Project 1
"""
from typing import Dict, List, Optional

from generate import generate_processes
from collections import deque, defaultdict
from process_input import write_to_file
from timer import Timer
from processor import Processor
from process import Process


class Scheduler:
    def __init__(
        self,
        method: Optional[str] = "",
        process_list: Optional[List[Process]] = None,
        limit: Optional[int] = None,
        name: str = "default",
    ) -> None:

        current_processes = [p for p in process_list if p.start_time == 0]
        future_processes = [p for p in process_list if p.start_time > 0]

        if method == "SJF" and process_list is not None:
            # sort by cycles first in ascending order, tiebreaker is PID
            self.process_list = deque(sorted(current_processes))
        else:
            self.process_list = (
                deque(current_processes) if current_processes is not None else deque()
            )

        self.processors = [Processor(limit=limit) for _ in range(6)]
        self.method = method
        self.timer = Timer()
        self.completed_processes = deque()
        self.name = name

        # stores processes whos start times happen in the future
        self.future_process_dict = defaultdict(list)

        if future_processes:
            self.add_processes_in_future(future_processes)

    def add_process_list(self, processes: List[Process]) -> None:
        """
        WARNING: MUTATES start time of processes
        Add all processes in list, set start time to current time.
        """
        for p in processes:
            p.start_time = self.timer.get_time()
        self.process_list.extend(processes)

    def do_cycle(self) -> None:
        """
        Increment the cycle of every processor by 1.
        CPU will always complete a process cycle if any incompleted processes remain.
        """
        self.check_for_new_processes()
        for p in self.processors:
            if not p.do_cycle():
                # no process in processor or process cycle count is 0
                process = p.process
                if not process:
                    p.set_process(self.get_process())

                else:
                    # process is completed
                    if process.cycles == 0:
                        process.end_time = self.timer.get_time()
                        self.completed_processes.append(process)
                    else:
                        # occurs during round robin
                        self.process_list.append(process)
                    p.set_process(self.get_process())

                if p.process:
                    # don't waste cpu cycle when cpu didn't complete a cycle
                    # (due to process being completed, no process existing,
                    # or round robin limit reached)
                    p.do_cycle()
        self.timer.increment()

    def processes_remain(self) -> bool:
        """
        Returns true if processes are currently within a processor,
        if processes are waiting in scheduler, or if future processes are
        going to get introduced in the future.
        """
        if self.process_list or self.future_process_dict:
            return True
        return any([p.process for p in self.processors])

    def get_process(self) -> Optional[Process]:
        if not self.process_list:
            return None
        return self.process_list.popleft()

    def average_waiting_time(self) -> float:
        total_waiting_time = sum(
            [p.get_waiting_time() for p in self.completed_processes]
        )
        process_count = len(self.completed_processes)

        return total_waiting_time / process_count

    def average_turnaround_time(self) -> float:
        total_turnaround_time = sum(
            [p.get_turnaround_time() for p in self.completed_processes]
        )
        process_count = len(self.completed_processes)
        return total_turnaround_time / process_count

    def __repr__(self):
        return f"{self.name} Scheduler<remaining={self.process_list}, completed={self.completed_processes}>"

    def check_for_new_processes(self):
        """
        Checks if there are processes that are supposed to be added to the scheduler at the current time.
        If so, add them to the process list, and delete the entry in the future process dict.
        """
        curr_time = self.timer.get_time()
        if curr_time in self.future_process_dict:
            self.process_list.extend(self.future_process_dict[curr_time])
            del self.future_process_dict[curr_time]

    def add_processes_in_future(self, processes: List[Process]):
        for p in processes:
            self.future_process_dict[p.start_time].append(p)


def copy_processes(process_list: List[Process], count) -> List[List[Process]]:
    return [[p.copy() for p in process_list] for _ in range(count)]


def compare_schedulers(schedulers: List[Scheduler]) -> None:
    """Runs all given schedulers and outputs the average waiting time and turnaround time for each scheduler."""
    for s in schedulers:
        while s.processes_remain():
            s.do_cycle()
        print(
            f"{s.name:9}| avg waiting: {s.average_waiting_time():8.1f} | avg turnaround: {s.average_turnaround_time():8.1f}"
        )


if __name__ == "__main__":
    processes = copy_processes(generate_processes(250), 7)
    # processes = copy_processes(
    #     [Process(i, 10000, 10000, start_time=100) for i in range(10)], 7
    # )
    schedulers = [
        Scheduler(process_list=processes[0], name="FIFO"),
        Scheduler(method="SJF", process_list=processes[1], name="SJF"),
        Scheduler(process_list=processes[5], limit=2, name="RR2"),
        Scheduler(process_list=processes[2], limit=200, name="RR200"),
        Scheduler(process_list=processes[3], limit=2000, name="RR2000"),
        Scheduler(process_list=processes[4], limit=5000, name="RR5000"),
    ]
    compare_schedulers(schedulers)
