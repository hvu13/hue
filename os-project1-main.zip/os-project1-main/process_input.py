# pylint: skip-file
from typing import List
from process import Process
import csv


def get_input_from_file(include_first_row: bool = False) -> List[Process]:
    """
    Reads a `processes.csv` file from current directory and converts
    to processes for the application.
    NOTE: Assumes the order of columns is: (PID, Cycle Count, Memory)
    """
    with open("processes.csv", mode="rt", encoding="utf8", newline="") as csv_file:
        process_reader = csv.reader(
            csv_file,
        )
        process_list = []
        for line_number, row in enumerate(process_reader, 1):
            if not include_first_row and line_number == 1:
                continue
            try:
                process_list.append(Process(int(row[1]), int(row[2]), int(row[0])))
            except ValueError as error:
                raise ValueError(
                    f"processes.csv contains a non-integer value on line: {line_number}.\n"
                    + f"The line's values were '${row}'"
                ) from error
        return process_list


def write_to_file(processes: List[Process]) -> None:
    """Write a list of processes to a `processes.csv` file."""
    process_list = [(p.pid, p.cycles, p.memory) for p in processes]
    with open("processes.csv", mode="wt", encoding="utf8", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Process ID", "CPU Cycles", "Memory Requirement"])
        # Write Process Data
        writer.writerows(process_list)


if __name__ == "__main__":
    processes = get_input_from_file()
    print(processes[:3])
