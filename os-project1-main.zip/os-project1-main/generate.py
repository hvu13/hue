# pylint: skip-file

import random
from time import process_time
from typing import List

import matplotlib.pyplot as plt

from process import Process

CYCLE_UPPER = 11000
CYCLE_MEAN = 6000
CYCLE_LOWER = 1000
STD_DEV = (CYCLE_UPPER - CYCLE_MEAN) / 3.8

MEMORY_UPPER = 100 * 2**10  # 100 KB
MEMORY_MEAN = 20 * 2**10  # 20 KB
MEMORY_LOWER = 2**10  # 1 KB


def random_cycle_count_normal_distribution(
    mean=CYCLE_MEAN, std_dev=STD_DEV, upper=CYCLE_UPPER, lower=CYCLE_LOWER
):
    """
    Normal distribution which contains but has it's extreme zones truncated.
    """
    return int(within_bounds(lower, upper, random.gauss(mean, std_dev)))


def random_memory_with_mean(minimum, maximum, mean, size=100):
    """
    Creates a distribution with given mean.
    Selects memory range to select form based on current mean and target mean.
    I chose this method to make the resulting mean more reliable, because true random
    numbers had more variance, even with large (10,000) sample sizes.
    """
    std_lower = (mean - minimum) / (3 * 2)  # lower range standard deviation
    avg_lower = (
        mean + minimum
    ) * 0.6  # place slightly closer to avg instead of equidistant
    avg_upper = (
        mean + maximum
    ) * 0.4  # place slightly closer to avg instead of equidistant
    std_upper = (avg_upper - minimum) / 3  # upper range standard deviation
    curr_sum = random.randint(minimum, maximum)  # initialize with random number
    res = [curr_sum]
    i = 1
    while i < size:
        curr_mean = curr_sum / i
        if curr_mean >= mean:
            # add within lower range
            res.append(
                within_bounds(minimum, maximum, int(random.gauss(avg_lower, std_lower)))
            )
        else:
            # add within upper range
            res.append(
                within_bounds(minimum, maximum, int(random.gauss(avg_upper, std_upper)))
            )
        curr_sum += res[-1]
        i += 1
    return res


def within_bounds(lower, upper, val):
    """Keep value within the upper and lower limit"""
    return max(min(upper, val), lower)


def create_cycle_chart(processes: List[Process]) -> None:
    """Create a chart of the cyles of the processes. Output file name is process-cycles.png"""

    cycles = [p.cycles for p in processes]
    minimum = min(cycles)
    mean = sum(cycles) / len(cycles)
    maximum = max(cycles)
    plt.xlabel("Cycles (100 bins)")
    plt.ylabel("Frequency")
    plt.title(
        f"Process Cycle Distribution \n(n=10,000, min: {minimum}, mean: {mean:.1f}, max: {maximum})"
    )
    plt.hist(cycles, bins=100)
    plt.savefig("process-cycles")


def create_memory_chart(processes: List[Process]) -> None:
    """Create a chart of the memory of the processes. Output file name is process-memory.png"""

    memory = [p.memory for p in processes]
    minimum = min(memory)
    mean = sum(memory) / len(memory)
    maximum = max(memory)
    plt.xlabel("Memory (100 bins)")
    plt.ylabel("Frequency")
    plt.title(
        f"Process Memory Distribution \n(n=10,000, min: {minimum}, mean: {mean:.1f}, max: {maximum})"
    )
    plt.hist(memory, bins=100)
    plt.savefig("process-memory")


def output_to_text_file(processes: List[Process]) -> None:
    """Optional. Output processes to text file"""
    with open("output.txt", "wt", encoding="utf-8") as f:
        for process in processes:
            print(f"{process.pid}, {process.cycles}, {process.memory}", file=f)


def generate_processes(size=10000) -> List[Process]:
    """Generate processes, defaults to 10,000"""
    # create random cycles
    cycles = [random_cycle_count_normal_distribution() for _ in range(size)]

    # create random memory
    memory = random_memory_with_mean(MEMORY_LOWER, MEMORY_UPPER, MEMORY_MEAN, size=size)

    # create processes from random cycles and memory
    processes = [
        Process(pid=pid, cycles=c, memory=m)
        for pid, (c, m) in enumerate(zip(cycles, memory), 1)
    ]

    # create_cycle_chart(processes)

    # clear graph to allow for memory chart to be created
    # plt.clf()

    # create_memory_chart(processes)

    # output_to_text_file(processes)  # uncomment to create output text file

    return processes


if __name__ == "__main__":
    generate_processes()
