# Algorithms

## Algorithm 1

SJF, same as problem #1 but you need to calculate average wait time and averarge turn around time differently. (Look at professor said about measuring different speed cpus). Treat every cpu as the same speed when assigning processes, but calculate the metrics after everythign is completed to account for the different CPU speeds

## Algorithm 2

Get processes in sorted order. Add the processes in descending order based on cycle count, to the processor which would complete the process in the least time. Use a private queue for each processor, instead of sharing a common process queue.

## Algorithm 3

greedy partition solution ()

## Algorithm 4

sort array, distribute top half of processes to fastest processors. Distribute bottom have to slowest processors

`A CPU with a clock speed of 3.2 GHz executes 3.2 billion cycles per second. (Older CPUs had speeds measured in megahertz, or millions of cycles per second.)`

- Maybe we should use milliseconds, microseconds, or nanoseconds when comparing times?
- 2GHz = 2 \* 10^9
- 4GHz = 4 \* 10^9
- 6000 avg cycles per process \* 250 processes = 1.5 \* 10^6
- perfect schedule with 4x2ghz of 250 processes each with 6000 cycle count (total time)
  - 187,500 nano seconds
    - `(6000×250 / (4×2×10^9))×(10^9)`
  - 187.5 microseconds
  - 0.1875 milliseconds
- perfect schedule with 4x4ghz of 250 processes each with 6000 cycle count (total time)
  - 93,750 nano seconds
    - `(6000×250 / (4×4×10^9))×(10^9)`
  - 93.75 microseconds
    - `(6000×250 / (4×4×10^9))×(10^6)`
  - 0.09375 milliseconds
    - `(6000×250 / (4×4×10^9))×(10^3)`
