# pylint: skip-file

from dataclasses import dataclass, field, asdict
from typing import Optional
from random import randint


@dataclass(order=True)
class Process:
    """Process data structure, sortable based off cycles remaining"""

    cycles: int
    memory: int
    pid: int
    start_time: int = field(repr=False, default=0, compare=False)
    original_cycle_count: int = field(repr=False, init=False, compare=False)
    end_time: Optional[int] = field(repr=False, default=None, compare=False)

    def __post_init__(self):
        self.original_cycle_count = self.cycles

    @classmethod
    def copy(cls, process: "Process") -> "Process":
        """Deep Copy a provided process"""
        process_attrs = asdict(process)
        del process_attrs["original_cycle_count"]
        return Process(**process_attrs)

    def copy(self) -> "Process":
        """Deep copy the current process"""
        process_attrs = asdict(self)
        del process_attrs["original_cycle_count"]
        return Process(**process_attrs)

    def get_waiting_time(self):
        if not self.end_time:
            raise ValueError("process has not been completed")
        return self.end_time - self.start_time - self.original_cycle_count

    def get_turnaround_time(self):
        if not self.end_time:
            raise ValueError("process has not been completed")
        return self.end_time - self.start_time


if __name__ == "__main__":
    processes = [
        Process(
            randint(1, 100),
            randint(1, 100),
            randint(1, 100),
        )
        for _ in range(10)
    ]
    print(processes)
    sorted_p = sorted(processes)
    print(sorted_p)
    print(Process.copy(processes[0]))
    print(processes[0].copy())
    assert Process.copy(processes[0]) == processes[0].copy()
