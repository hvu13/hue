# pylint: skip-file

from itertools import count


class Timer:
    def __init__(self):
        self.ticker = count()
        self.time = next(self.ticker)

    def increment(self):
        self.time = next(self.ticker)

    def get_time(self):
        return self.time

    def __repr__(self):
        return f"Timer<{self.time}>"
